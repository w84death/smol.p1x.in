"""
smolOS - boot script
-------------------------------------------------
Specialized Microcontroller-Oriented Lightweight Operating System

(c)2023/07 Krzysztof Krystian Jankowski
Homepage: https://smol.p1x.in/os/
"""
from smolos import smolOS
os=smolOS()
os.boot()
print("Bye!")
